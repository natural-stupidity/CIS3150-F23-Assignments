/* Parse tree using ASCII graphics
        -original NCurses code from "Game Programming in C with the Ncurses Library"
         https://www.viget.com/articles/game-programming-in-c-with-the-ncurses-library/
         and from "NCURSES Programming HOWTO"
         http://tldp.org/HOWTO/NCURSES-Programming-HOWTO/
*/ 

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <ncurses.h>

#define SCREENSIZE 200

	// current position in string
int position;
	// indentation
int width;

int regexp(char *, int);


	// draws text on screen at location (depth, width) using ncurses
void print(int depth, char *str) {
	// offset in depth, used to break line and move it down the screen
	// when the max line length is reached
static int offset = 0;

	// if the output reaches the max width of the window then
	// move down and back to the left edge (carriage return and newline)
   if (width > 150) {
      width = 0;
      offset += 15;
   }
	// ncurses command to draw textstr 
   mvprintw(depth+offset, width, str);
}


int drawTree(char *regex) {
char c;
int depth = 0;

	// start in leftmost position
   width = 0;

	// ncurses clear screen
   clear();

        // parse tree
	// parsing functions calls print to draw output
	// -regex is the string containing the regular expression to be parsed
	// -depth contains the current depth in the parse tree, it is
	//    incremented with each recursive call 
   regexp(regex, depth);

   refresh();

        // read keyboard and exit if 'q' pressed
   while(1) {
      c = getch();
      if (c == 'q') return(1);
   }
}


int concat(char *regex, int depth) {
   return(1);
}


int regexp(char *regex, int depth) {
print(depth, "regexp");
      if (concat(regex, depth+1)) {
         return(1);
      } else {
         return(0); 
      }
}


int main() {
char *ptr = "a";

        // initialize ncurses
   initscr();
   noecho();
   cbreak();
   timeout(0);
   curs_set(FALSE);

	// replace the static regular expression with a string read
	// from the input file - do this before calling drawTree()

	// traverse and draw the parse tree
   position = 0;
   drawTree(ptr);

        // shut down ncurses
   endwin();
}

