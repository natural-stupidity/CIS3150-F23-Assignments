/* Parse tree using ASCII graphics
        -original NCurses code from "Game Programming in C with the Ncurses Library"
         https://www.viget.com/articles/game-programming-in-c-with-the-ncurses-library/
         and from "NCURSES Programming HOWTO"
         http://tldp.org/HOWTO/NCURSES-Programming-HOWTO/
*/ 

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifndef NOGRAPHICS
#include <unistd.h>
#include <ncurses.h>
#endif

#define SCREENSIZE 200



#ifndef NOGRAPHICS
	// curses output
	// row indicates in which row the output will start - larger numbers
	//      move down
	// col indicates in which column the output will start - larger numbers
	//      move to the right
	// when row,col == 0,0 it is the upper left hand corner of the window
void print(int row, int col, char *str) {
   mvprintw(row, col, str);
}
#endif



int main(int argc, char *argv[]) {
int c;

#ifndef NOGRAPHICS
        // initialize ncurses
   initscr();
   noecho();
   cbreak();
   timeout(0);
   curs_set(FALSE);
#endif

	/* read and interpret the file starting here */


#ifndef NOGRAPHICS
	/* loop until the 'q' key is pressed */
   while(1) {
      c = getch();
      if (c == 'q') break;
   }

        // shut down ncurses
   endwin();
#endif
}

